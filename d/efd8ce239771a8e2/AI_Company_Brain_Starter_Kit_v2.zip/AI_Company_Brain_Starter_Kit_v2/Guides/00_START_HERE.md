---
title: Start Here
description: Thirty minutes from nothing to a working setup, using the AI you already pay for.
---

# Start here

You already pay for ChatGPT or Claude. You already use it most days. And you have probably noticed the same thing everyone notices after a few months: it is brilliant in the moment and useless the next morning. You explain your business again. You paste the same background again. You get a good answer, close the tab, and it is gone.

That is not a problem with the AI. It is a problem with the setup around it. This kit is the setup.

## What this actually is

Two things, and neither of them is software you have to buy.

**A company brain.** One folder of plain files on your computer holding what your business knows: your clients, your projects, your prices, your decisions, your meeting notes. You read and write it in a free app called Obsidian.

**A set of skills.** Nine named jobs you can hand to ChatGPT or Claude, written out in full, ready to copy and paste. Things like "write up my week", "onboard a new client", "draft the chase email", "turn these meeting notes into actions". You install them once and use them for years.

Put together, you stop chatting with AI and start running your business through it. You paste in the file, you run the skill, you get the same quality of output every time, because the instructions are the same every time.

## What you need

- **Obsidian.** Free, from obsidian.md. Free for business use too. This is the only thing you install.
- **The AI subscription you already have.** ChatGPT Plus or Claude Pro, either is fine. Both work. You do not need a new one.
- **Thirty minutes.** Genuinely. Set a timer.

That is the whole list. No new subscription, no coding, no plugins, no accounts to create.

## Your files are yours

Everything you write lives in ordinary text files in a folder on your own computer. Not in a database. Not in someone's app. Not behind a login.

That matters more than it sounds. If Obsidian disappeared tomorrow, your files would still open in Notes, Word, TextEdit, or anything else with a cursor. If you switch computers, you copy a folder. If you want to back it up, you back up a folder. There is no export button because there is nothing to export from. In thirty years those files will still open.

Most business software rents you access to your own information. This does not.

## What you will have in thirty minutes

- A folder on your computer with eight labelled sections, ready to fill.
- One MASTER file that tells the AI who your business is, so you never explain it again.
- Your most important client written down properly, in one page.
- Your first skill installed and run, on real work, with a real answer back.

## The thirty minutes

| Time | What you do | Where |
|---|---|---|
| 0 to 5 | Install Obsidian, create the folder | 01_Your_Company_Brain |
| 5 to 20 | Write the MASTER file and one client page | 01_Your_Company_Brain |
| 20 to 30 | Install and run your first skill | 02_Your_Skills |

Then read `03_Running_It_Weekly.md` when you have a spare ten minutes. That one is about the habit, and the habit is what decides whether this is still working in six months or sitting in your downloads folder.

## The five files in this kit

1. **00_START_HERE.md** (this one). What it is and how the thirty minutes go.
2. **01_Your_Company_Brain.md.** The folder structure, the MASTER file, and every page template you need.
3. **02_Your_Skills.md.** The nine skills. This is the part you will use every week.
4. **03_Running_It_Weekly.md.** Daily two minutes, weekly twenty, monthly hour.
5. **04_When_Your_Data_Cant_Leave.md.** For the day a client asks where their information goes. Read it before that day, not after.

## Be honest about one thing first

This works if you write things down. It is not magic and it does not read your mind. The AI can only be as good as what you show it, and what you show it is what you wrote last week.

The good news is that the writing is small. Three bullets after a call. Two lines when you decide something. Five minutes on a Friday. The kit is built so that small amounts of writing produce large amounts of use.

## Do this now

Go to obsidian.md, download it, and install it. That is it for this file. Two minutes. Then open `01_Your_Company_Brain.md` and keep going.
