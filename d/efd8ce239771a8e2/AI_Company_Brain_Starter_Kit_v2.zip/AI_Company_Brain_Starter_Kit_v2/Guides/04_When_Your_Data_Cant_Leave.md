---
title: When Your Data Cannot Leave
description: The day cloud AI stops being fine, what your options actually are, and how much they cost.
---

# When your data cannot leave

Everything in this kit so far sends your text to ChatGPT or Claude. For most work, most of the time, that is fine. Both companies are serious about security, both offer business terms, and the alternative for most small businesses is a filing system nobody can search.

But there is a day when it stops being fine, and it is better to know what that day looks like before it arrives.

## How you will know

It is usually one of these.

**A client asks in writing.** "Do you use AI tools to process our information, and if so, which ones and where is the data held?" This question is now standard in supplier forms, and it is going to get more common, not less.

**You sign something that says you cannot.** An NDA with a clause about third-party processing. A contract that names approved subcontractors. A data agreement you skim-read that turns out to cover exactly this.

**Your sector has rules.** Legal, medical, financial advice, anything involving children, anything holding case files. In these fields the question is not whether it is technically safe, it is whether you can put it in writing that it never left.

**Your own gut.** You go to paste something in and you hesitate. That hesitation is information. It is usually correct.

Any one of those, and the honest answer is that this specific work needs a different setup. Not all your work. That specific work.

## What is actually true about the cloud option

Before you panic and rip everything out, get the facts straight.

Paid business plans from the major AI companies do not use your conversations to train their models. That is in their terms and it is a meaningful commitment. They are almost certainly more secure than your email is.

What you cannot say, and what a serious client is really asking, is that the information never left your building. It did. It went to a data centre owned by someone else, under terms that can change, in a country you may not have chosen. For most work that is an acceptable trade. For some work it is not, and no amount of reassurance changes it.

So the question is not "is the cloud safe". It is "can I put in writing that this particular client's information never left my control". Sometimes you need to be able to say yes.

## Option one: keep it out

The cheapest answer and the one people skip.

Some work simply does not go through AI. You do it the old way, and you write down which categories those are. One line in your MASTER file: "Client files for X and Y never go into any AI tool."

If you can do that without much pain, do that. It costs nothing and it is completely defensible.

## Option two: run the AI on your own computer

You can download an AI model onto your own machine and run it with no internet connection at all. Genuinely none. Turn the wifi off and it still answers. Nothing you type ever leaves the room.

This is real, it is free, and a reasonably modern computer can do it. It is also more work than installing an app, and the answers are not as sharp as ChatGPT. Both of those things are true at the same time, and anyone who tells you otherwise is selling something.

**What you need.** A Mac from 2020 or later with an Apple chip, or a Windows machine with a decent graphics card. 16GB of memory is comfortable, 8GB works but slowly. About 10GB of free disk space.

**How you do it.** Install a free app called Ollama from ollama.com. Open it. Then open Terminal and run these two lines:

```bash
ollama pull llama3.1:8b
ollama run llama3.1:8b
```

The first line downloads the model, which takes a few minutes and only ever happens once. The second starts a chat. Type a question, press return, and you have a private AI running on your own machine.

To use it on your files, copy a page out of Obsidian and paste it into that chat with one of the skills from this kit above it. That is the whole workflow. It is the same as everything you have learned, with a different window.

**What you should expect.** Slower answers. Less polish. It is good at summarising notes you give it, pulling actions out of meeting notes, and first drafts. It is weaker at anything long, subtle, or requiring several steps of reasoning. Treat what it says as a sharp first draft, never as final, and check anything involving money or a promise to a client.

**Two things that will catch you out.** It can only hold so much text at once, so give it one page at a time rather than your whole folder. And check what your backup software is doing, because a private setup with your folder syncing to a cloud drive is not private.

If you are comfortable with the two lines above, this route costs you nothing but an afternoon. Plenty of people stop here and never need anything else.

## Option three: have it done for you

If the above sounds like a weekend you do not have, or the stakes are high enough that "I set it up myself and I think it is fine" is not an answer you want to give a client, this is what we do at Heoka.

We install a private AI setup on hardware in your office. Your files, your building, no internet needed for it to work. Your staff use it like any other chat window. Nothing goes out.

**The starting point is a £500 audit.** Half a day. We look at what information you actually hold, which of it genuinely cannot leave, what your clients and contracts require of you, and whether a private setup is worth the money in your case.

You get a written report either way. Sometimes that report says you do not need us, and if it does, we say so, because the alternative is selling you a machine you will resent in six months.

If it does make sense, the report tells you what it would cost and what it would do. No obligation attached to it.

Book here: https://calendar.app.google/C2fbqws67vmDvneV7

If you are not there yet, that is completely fine. Most people using this kit are not. Keep the link. The day a client sends you that question in writing, you will want to have already had the conversation.

## Do this now

Open `00_System/MASTER.md` and add one line under the rules section: which of your clients or which categories of your work should never go into a cloud AI tool. Even if the answer is "none of it, for now". Writing it down is the point. It takes two minutes and it means the decision is made before the pressure arrives.
