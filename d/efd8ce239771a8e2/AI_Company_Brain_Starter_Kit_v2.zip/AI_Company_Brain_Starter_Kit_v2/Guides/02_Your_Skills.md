---
title: Your Skills
description: Nine named jobs you can hand to ChatGPT or Claude. Install once, use for years.
---

# Your skills

A skill is a job with a name.

Not a clever prompt you wrote at 11pm and never found again. A named, written-down job that produces the same quality of output every single time you run it, because the instructions are identical every time you run it. "Weekly Review." "Chase Email." "Meeting Notes to Actions."

That is the difference between using AI and having AI in your business. You stop inventing the instruction each time. You just pick the job.

There are nine here. You will probably use four of them constantly and the others when the moment comes. Start with one.

## How to install them

Do this bit first. It takes five minutes and everything afterwards is easier.

### If you use ChatGPT

**The one thing to do: set up a Project.**

1. In the left sidebar, click **Projects**, then **New project**. Call it your business name.
2. Open the project, find the instructions box (it may be called "Instructions" or sit behind an "Add instructions" link).
3. Paste in your whole `00_System/MASTER.md` file. All of it.
4. Save.

Every chat you start inside that project now already knows who you are, how you write, and what your rules are. You never explain your business again.

Then, for each skill you want to keep: start a new chat inside the project, paste the skill, and rename the chat to the skill name. It sits in your sidebar ready to reuse. Or keep the skills in `05_Skills` in your brain folder and copy from there, which is the approach that survives you switching AI tools later.

**Custom Instructions** (Settings, then Personalisation, then Custom Instructions) is where the short version of your MASTER file goes if you want it applied to every chat, project or not. Paste in the "How we work" and "Rules for the AI" sections. There is a length limit, so keep it to the essentials.

### If you use Claude

**Set up a Project.**

1. Click **Projects**, then **Create project**. Name it your business name.
2. Find **Set project instructions** (sometimes shown as "Add custom instructions").
3. Paste in your whole `00_System/MASTER.md`.
4. In the same project, use **Add content** to attach the files you refer to most: your client pages, your recurring costs page. Claude reads them when relevant, so you paste less.

Every chat in that project starts with your business already understood.

For the skills themselves, save each one in `05_Skills` in your brain folder and paste when you need it.

### Either way

Save the nine skills below as nine files in `05_Skills` in your company brain. Then you own them, and they still work if you switch from ChatGPT to Claude next year or to whatever comes after.

## How to run one

Every skill works the same way.

1. Open your project chat.
2. Paste the skill.
3. Paste whatever it asks for underneath, usually a file from your brain or some rough notes.
4. Send.

Where a skill says `[paste ...]`, that means copy the text out of the relevant page in Obsidian (click into the note, Ctrl+A or Cmd+A, then Ctrl+C or Cmd+C) and paste it in place of the bracket.

You can also attach the file instead of pasting, in either tool. Same result, fewer keystrokes.

---

## Skill 1: Weekly Review

**What it does.** Reads your week's notes and tells you what actually happened, including what you dropped.

**When to use it.** Friday afternoon, or Monday morning if Fridays are chaos. Once a week, same slot.

**Paste this:**

```text
You are my business assistant. Below are my notes from the past week.

Read them and give me exactly four sections, with these headings:

WINS. Up to 3 bullets. What genuinely moved.

PROBLEMS. Up to 3 bullets. What went wrong or is going wrong.

DROPPED BALLS. Anything mentioned as needing action where there is
no sign it was done. This section matters most, so be thorough
and slightly annoying about it.

NEXT WEEK. The 3 most important actions, hardest first.

Rules: keep every bullet under 15 words. Only use what is in my
notes. If you are inferring something rather than reading it,
say so.

My notes:
[paste this week's meeting notes and any daily notes]
```

**What good output looks like.** Short. Specific to your actual week, with real names and real numbers in it. The dropped balls section should make you slightly uncomfortable and contain at least one thing you had genuinely forgotten. If the output could apply to any business, your notes were too thin, not the AI.

---

## Skill 2: Client Onboarding Runner

**What it does.** Turns a signed client into a full client page, a task list, and a welcome email, in one go.

**When to use it.** The hour after someone says yes, while you still remember what you promised them.

**Paste this:**

```text
You are my business assistant. I have just won a new client. Below
are my rough notes from the sales conversation.

Produce three things, clearly separated.

ONE: a client page with these exact headings: Basics, How they like
to work, Where things stand, History, Risks and opportunities.
Put every fact from my notes under the right heading. Where I have
not given you the information, write TODO rather than guessing.

TWO: an onboarding task list for me. Every single thing that has to
happen before this client is properly running, based on what I
promised in my notes plus the obvious steps for this kind of work.
Format as a checklist with who owns each item.

THREE: a welcome email to the client. Under 150 words. Confirms
what we agreed, says what happens next and when, and asks for
anything I need from them. Do not promise any date that is not
in my notes.

My rough notes:
[paste your notes from the sales call]
```

**What good output looks like.** The client page is ready to save straight into `03_Clients` with a few TODOs to fill. The task list includes at least one thing you had not thought of. The email sounds like you, because your MASTER file told it how you write.

---

## Skill 3: Proposal Drafter

**What it does.** Turns a conversation with a prospect into a proposal you can edit and send.

**When to use it.** Same day as the meeting, when you are still clear on what they actually asked for.

**Paste this:**

```text
You are my business assistant. Draft a proposal.

Below are my notes from the conversation, plus what I sell and what
I charge. Write a proposal with these sections:

THE PROBLEM. Their situation in their own words from my notes.
Do not soften it and do not add problems they did not mention.

WHAT WE WILL DO. The work itself, in plain terms, as bullets.

WHAT YOU GET. The outcome, not the activity.

WHAT IT COSTS. Use only prices from my notes. If a price is
missing, write PRICE TBC rather than making one up.

WHAT IS NOT INCLUDED. Be specific here. This section prevents
arguments later, so think about what a client could reasonably
assume is included and rule it out.

TIMELINE AND NEXT STEP. One clear action for them to take.

Rules: no hype words, no filler. Under 600 words. Then, separately
below the proposal, list anything I have not told you that I need
to nail down before sending this.

My notes:
[paste the meeting note]

What I sell and charge:
[paste 01_Company pricing, or your MASTER file if the prices are in it]
```

**What good output looks like.** A draft you edit for twenty minutes rather than write from scratch for two hours. The "not included" section should name two or three things you would have forgotten. The list of gaps at the end is the most useful part, read it before you read the proposal.

---

## Skill 4: Meeting Notes to Actions

**What it does.** Takes messy notes from a call and pulls out who owes what to whom by when.

**When to use it.** Within ten minutes of the call ending. Every time.

**Paste this:**

```text
You are my business assistant. Below are my rough notes from a
meeting. Turn them into a clean meeting note with these headings:

WHAT WAS DISCUSSED. Short bullets. What they said matters more
than what I said.

DECISIONS MADE. Only actual decisions, not discussion.

ACTIONS. Format each one as: owner | what | by when.
If my notes do not say who owns it or when it is due, write
UNASSIGNED or NO DATE rather than guessing. Put my own actions
first.

OPEN QUESTIONS. Anything left hanging.

FOR NEXT TIME. Anything to remember before I speak to them again.

Rules: keep my meaning exactly. Fix my grammar and spelling.
Add nothing I did not say. Output it as a markdown note I can
save straight into my folder.

My rough notes:
[type or paste whatever you scribbled]
```

**What good output looks like.** Every promise made in the room appears in the actions list, including the vague ones, marked UNASSIGNED so you have to deal with them. Nothing appears that you did not say. Save the output into `06_Meetings` with today's date in the filename and you are done.

---

## Skill 5: Chase Email Drafter

**What it does.** Writes the awkward follow-up email you have been avoiding. Unpaid invoices, silent prospects, clients who owe you information.

**When to use it.** The moment you notice the silence, instead of three weeks later.

**Paste this:**

```text
You are my business assistant. Draft a chase email.

Situation: [choose one and delete the rest]
- An invoice is unpaid
- A prospect has gone quiet after a good conversation
- A client owes me something I need to do my job

The facts:
- Who: [name and their role]
- What I am chasing: [invoice number and amount, or the thing they owe me]
- When it was due or when we last spoke: [date]
- How overdue: [number of days]
- History: [anything relevant, e.g. they have always paid on time]

Write the email. Rules:
- Under 100 words.
- Polite, direct, assumes good faith. No apologising for chasing.
- Never use the phrase "just checking in" or "circling back".
- One clear ask, with one clear thing they can reply with.
- Do not threaten anything or mention late payment charges unless
  I told you to.
- Include a subject line.

Then, underneath, write a second version that is one notch firmer,
for if there is no reply in a week.
```

**What good output looks like.** Two emails. The first is short enough that you send it without editing. The second is firmer without being rude, and you have it ready so the follow-up actually happens.

---

## Skill 6: Monthly Numbers Questions

**What it does.** Looks at your costs and admin facts and asks the questions you should be asking yourself.

**When to use it.** Once a month, when the card statements land.

**Paste this:**

```text
You are a blunt finance-minded adviser. Below are my recurring
costs and admin notes.

Give me four things.

ONE: a table with columns Item, Cost per month (convert any annual
figures to monthly), and Keep or Question. Mark as Question
anything that looks duplicated, unused based on my notes, or
expensive for what it is.

TWO: the total monthly cost, and the total of everything you
marked Question. Show your working for the annual conversions.

THREE: every date, deadline and renewal you can find in my notes,
sorted earliest first, in the format DATE | what it is. Today is
[type today's date]. Put SOON at the start of anything in the
next 30 days.

FOUR: the five questions I should be able to answer about this
business and probably cannot from these notes alone. Be specific
to what you can see, not generic.

Do not invent any figure or date. If something is missing, say
it is missing.

My notes:
[paste 04_Finance_Admin/Recurring_Costs.md and any other admin notes]
```

**What good output looks like.** A table you check the arithmetic on yourself, at least two subscriptions you had forgotten you pay for, and a renewal date you were about to be ambushed by. Section four is the one worth reading twice.

---

## Skill 7: Decision Log Writer

**What it does.** Turns a decision you just made into a written record of why you made it.

**When to use it.** The same day you decide anything that costs money, changes direction, or you would struggle to explain in six months.

**Paste this:**

```text
You are my business assistant. I have made a decision and I want
it written down properly.

Turn my rough notes below into a decision record with these exact
headings: What we decided, Why, What we said no to, What this
commits us to.

Today's date is [type today's date].

Rules: keep my reasoning exactly as I gave it. Tidy the wording,
add nothing. If I have not said what I rejected, write "not
recorded" rather than inventing options. Output as a markdown
note I can save.

Then, separately, ask me up to three questions whose answers would
make this record more useful to read in a year's time.

My rough notes on the decision:
[type or paste what you decided and why]
```

**What good output looks like.** A short record you save into the project's `DECISIONS` folder in under a minute. The three questions at the end are the value. Answer them and paste them in.

---

## Skill 8: SOP Writer

**What it does.** Takes something only you know how to do and turns it into steps someone else could follow.

**When to use it.** Once a month, pick one job that lives only in your head. Especially before you hire, go on holiday, or get ill.

**Paste this:**

```text
You are my business assistant. Below is my rough description of
how we do a job in this business.

Turn it into a numbered step-by-step procedure that a new starter
could follow with no other help and nobody to ask.

Rules:
- Start with one line saying what this procedure is for and when
  it gets used.
- Number every step. One action per step.
- Where my description skips a step, is vague, or assumes knowledge
  I have not given you, insert a line that reads
  "CHECK: [what is unclear]" instead of guessing. Be picky about
  this, it is the point of the exercise.
- Name any tool, file or person needed at each step.
- End with a short "what good looks like" section and a
  "common mistakes" section based only on what I told you.

Output as a markdown note.

How we do it:
[describe the job roughly, as if talking someone through it on the phone]
```

**What good output looks like.** More CHECK lines than you expected. Those are the bits of the job that only exist in your head, which is exactly what you were trying to find. Answer them, re-run the skill, and file the result.

---

## Skill 9: Meeting Brief

**What it does.** Ten minutes before a meeting, tells you everything you should walk in knowing.

**When to use it.** Before every client meeting. This is the one that makes people think you have a better memory than you do.

**Paste this:**

```text
You are preparing me for a meeting. Below is my page on the person
or company I am meeting, plus the note from our last conversation.

Give me a brief with exactly these headings:

WHO. Two lines. Name, role, what they buy from us.

WHERE THINGS STAND. Three bullets.

WHAT I PROMISED LAST TIME. Every commitment I made, and whether
the notes show it was done. Be direct if something was not done.

WHAT THEY PROMISED. Same treatment.

LANDMINES. Anything sensitive, unresolved or awkward.

THREE QUESTIONS TO ASK. Specific to them, not generic.

Rules: under 250 words. Only use my notes. If something important
is obviously missing from my notes, say so at the end in one line.

My notes:
[paste the client page from 03_Clients and the last meeting note]
```

**What good output looks like.** Something you can read in ninety seconds on the way into the meeting. The "what I promised" section should occasionally catch you out, which is the whole reason it is in there.

---

## Making your own skills

When you write an instruction that works, save it in `05_Skills` with one line on when to use it. That is how the set grows.

Every skill above is built from the same five parts. Copy the pattern.

1. **Role.** "You are my business assistant." Or sharper when you need it: "You are a blunt adviser."
2. **Input.** Say exactly what you are giving it, then give it.
3. **Job.** One job. If you want two things, write two skills.
4. **Format.** The exact headings and limits you want back. This is what makes the output consistent rather than a wall of prose.
5. **Guardrail.** "Only use my notes. Do not invent anything. Say so if it is not there."

Five parts, every time. That is the whole craft, and now you have it.

## Do this now

Open ChatGPT or Claude, create a project, and paste your MASTER file into the instructions box. Then start a chat, paste Skill 4 (Meeting Notes to Actions), and run it on the notes from your last call, even if those notes are three scrappy lines on your phone. Five minutes, and you will see the point immediately.
