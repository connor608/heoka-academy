---
title: Running It Weekly
description: Two minutes a day, twenty minutes a week, an hour a month. The habit that decides whether this still works in six months.
---

# Running it weekly

Here is the honest bit. The folder and the skills are the easy part. You have done those in half an hour.

What decides whether this is still working next March is whether you write things down. Not lots. A little, often, at the same times. This file is that routine.

Everything here fits inside the time you already spend being disorganised.

## The three habits

| When | How long | What you do |
|---|---|---|
| End of each working day | 2 minutes | Capture what happened |
| Friday, same slot every week | 20 minutes | Run the Weekly Review, look at clients and projects |
| First working day of the month | 1 hour | Numbers, one procedure written down, one tidy-up |

Three habits. If you only ever manage one, make it the daily two minutes, because the other two are worthless without it.

## Daily: two minutes

At the end of the day, before you shut the laptop, open Obsidian and write down what happened. That is it.

You are answering four things, in bullets, badly:

- What did I do
- What did I decide
- Who owes me something
- What are the top three for tomorrow

Rough is fine. Fragments are fine. Spelling is irrelevant. Nobody is reading this except you and the AI, and the AI will tidy it whenever you need it tidy.

Where things go, if you want to be neat about it:

```mermaid
flowchart TD
    A[Something happened today] --> B{What was it about?}
    B -->|A client| C[03_Clients<br>update their page]
    B -->|A project| D[02_Active_Projects<br>update TASKS]
    B -->|A meeting or call| E[06_Meetings<br>new dated note]
    B -->|Money or admin| F[04_Finance_Admin]
    B -->|A decision| G[DECISIONS folder<br>one file per decision]
```

(In Obsidian this draws itself as a diagram. Or ignore it, it is only a picture of the paragraph above.)

Two rules make the two minutes work.

**Rough beats late.** Three bullets today beat a beautiful write-up on Sunday that never happens. If you had a call and typed nothing, type three words now.

**Same day, always.** A meeting note written on Friday about Tuesday's meeting is fiction. You will confidently write down things that did not happen.

If you had a proper call, this is where you run Skill 4 (Meeting Notes to Actions) on your scrappy notes. Ninety seconds, and you get a clean note plus every promise anyone made.

## Weekly: twenty minutes

Same slot every week. Friday afternoon works well, because the week is finished and Monday arrives with a plan already written. Put it in your calendar as a recurring event or it will not happen.

**Minutes 0 to 5: run the Weekly Review.**

Open your project chat, paste Skill 1, and paste in the week's notes from `06_Meetings`. Read what comes back, especially the dropped balls.

**Minutes 5 to 12: look at your clients.**

Open your two or three most important client pages. For each one, ask yourself one question: when did I last speak to them, and does that feel too long? Update the "Where things stand" section on each page while you are in there.

If one of them feels like it is going quiet, that is the signal. Do something about it today, not next month.

**Minutes 12 to 17: look at your projects.**

Open each active project's `TASKS.md`. Anything that has been in the "Now" section for three weeks is not a task, it is a problem. Either do it, break it into something smaller, or admit it is not happening and delete it.

Anything sitting in "Waiting on" for more than a week gets Skill 5 (Chase Email Drafter) run on it, right now, before you move on.

**Minutes 17 to 20: write next week down.**

Three priorities for next week, in a note. Hardest first. Then anything that finished this week gets moved to `99_Archive`.

That last move matters more than it looks. A folder where everything visible is live is a folder you can trust at a glance. A folder full of dead projects is one you start avoiding.

## Monthly: one hour

First working day of the month. This is the hour that stops the slow rot.

**Minutes 0 to 15: the numbers.**

Run Skill 6 (Monthly Numbers Questions) on your `04_Finance_Admin` notes. Check its arithmetic yourself. Cancel one thing you are paying for and not using. There is almost always one.

Diarise anything it flagged as coming up in the next 30 days.

**Minutes 15 to 35: get one job out of your head.**

Pick one thing that only you know how to do and run Skill 8 (SOP Writer) on it. Answer the CHECK questions it throws back. Save it in `00_System` or the relevant project folder.

Twelve months of this and you have twelve written procedures, which is the difference between a business and a job you cannot leave.

**Minutes 35 to 50: update the MASTER file.**

Open `00_System/MASTER.md` and reread it. Most of it will still be true. The section that will be out of date is "What is going on right now": the quarter's goal, the biggest problem, what you are worried about.

Update that section. Then paste the new version into your ChatGPT or Claude project instructions, replacing the old one. This is a two-minute job that keeps every answer you get for the next month accurate rather than six months stale.

**Minutes 50 to 60: tidy.**

Archive finished projects. Move former clients to `99_Archive`. Delete nothing.

Look at anything you have written this month that has no home and give it one.

## What it looks like after three months

Month one feels like admin. You are writing into a folder that is not yet answering you back, and it takes discipline.

Month two, the skills start returning things you did not know. The Weekly Review names a client you had not thought about in five weeks. The Meeting Brief reminds you of something you promised in March.

Month three, you stop reconstructing. You do not spend Monday morning working out where you were. You do not lose an afternoon looking for what you charged someone eighteen months ago. When a client rings out of nowhere, you open one page and you are ready in ninety seconds.

That is the whole return. It is not dramatic and it does not arrive in week one, which is exactly why most people never get it.

## When you fall off

You will. Everyone does, usually around a busy fortnight.

Do not try to reconstruct the missing weeks. It will be wrong and you will resent it. Just start again on the next working day and write down today. The folder does not care about the gap and neither should you.

The only version of this that fails is the one you abandon because you feel behind.

## Do this now

Open your calendar. Put a recurring twenty minute event in for Friday afternoon called "Weekly Review". Then open Obsidian and write today's three bullets, even if today was quiet. The habit starts with today, not Monday.
