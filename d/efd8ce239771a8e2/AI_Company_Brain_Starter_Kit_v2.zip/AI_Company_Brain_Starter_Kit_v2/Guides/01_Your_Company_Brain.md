---
title: Your Company Brain
description: The folder, the MASTER file, and every page template. Twenty minutes to a brain worth asking questions of.
---

# Your company brain

Your company brain is one folder of plain files. That is the whole trick. No database, no subscription, no export problem.

Obsidian is the free app you use to read and write those files. It does not store anything itself. It just gives you a nice window onto a folder that already exists on your computer. You could delete Obsidian tomorrow and every file would still be sitting there, readable in any app you own.

This is the part of the kit that takes twenty minutes. Do it once, add to it as you go.

## Step one: make the folder

1. Download Obsidian from obsidian.md and install it. On a Mac, drag it into Applications. On Windows, run the installer.
2. Open it and choose **Create new vault**. "Vault" is just Obsidian's word for folder.
3. Name it `CompanyBrain`. One word, no spaces.
4. Put it somewhere obvious and shallow, like your home folder or Documents. Not five levels deep.
5. Click Create. You are looking at an empty folder.

## Step two: make eight sections

In the left sidebar, right-click and choose **New folder**. Make these eight, exactly as written including the numbers:

```text
00_System
01_Company
02_Active_Projects
03_Clients
04_Finance_Admin
05_Skills
06_Meetings
99_Archive
```

The numbers are not decoration. They force the folders to always sort in the same order, in Obsidian and in Finder and in anything you point at the folder later. They also tell you how often you touch each one. Low numbers are rules and facts that barely change. Middle numbers are live work. 99 is the attic.

Here is what goes where.

**00_System.** How your brain works. The MASTER file lives here. You write this once and touch it a few times a year.

**01_Company.** Facts about your business that change slowly. What you sell, what it costs, who works here, who you sell to.

**02_Active_Projects.** One folder per live project. A project is anything with an end: a rebuild, a launch, a big proposal.

**03_Clients.** One page per client. The page you would hand someone taking over the account tomorrow.

**04_Finance_Admin.** Renewal dates, suppliers, insurance, contract terms, recurring costs. The facts you keep looking up. Not your accounts, your accounting software does that.

**05_Skills.** The skills from the next file in this kit, saved so they are always one copy away.

**06_Meetings.** Every meeting note, named by date: `2026-07-14_Acme_Review.md`. Date first, year first, so the folder sorts itself into a timeline without you doing anything.

**99_Archive.** Finished projects, former clients, dead documents. Move things here instead of deleting them.

One rule that matters everywhere: **no passwords, no bank details, no card numbers, ever.** Those belong in a password manager. This folder holds facts, not secrets.

## Step three: the MASTER file

This is the most valuable thing in the kit. If you only do one thing on this page, do this.

Every time you open a fresh chat, the AI knows nothing about you. So you explain. Then you explain again tomorrow. The MASTER file is you writing that explanation down once, properly, so you can paste it in and be understood in three seconds.

It answers three questions: **who this business is, how it works, and what the rules are.** Everything else in the brain is detail hanging off it.

Create `00_System/MASTER.md` and fill this in. Take fifteen minutes and do it honestly. Write like you are briefing a smart new employee on their first morning, including the awkward parts.

```markdown
---
title: MASTER
description: Read this first. Who we are, how we work, and the rules.
---

# MASTER

## Who we are

- Business name:
- What we sell, in one sentence:
- Who we sell it to:
- What we charge:
- Size: (just me / me plus 3 / 12 staff)
- Where we are:
- Website:

## How we make money

- Main way we earn:
- Typical job size and length:
- Where new work comes from:
- Busiest time of year:

## How we work

- Our tone with clients: (formal, friendly, blunt, warm)
- How we prefer to communicate: (email, phone, WhatsApp)
- What good work looks like here:
- What we never do:
- Words and phrases we use:
- Words and phrases we hate:

## The people

- Me: name, role, what only I can do
- Others: name, role, what they own

## What is going on right now

- The main thing we are trying to achieve this quarter:
- The biggest problem in the business right now:
- What I am worried about:

(Update this section monthly. Everything above it changes far less often.)

## Rules for the AI

When you are helping me, follow these.

- Plain English. Short sentences. No filler and no hype words.
- Only use facts from what I have given you. If the answer is not in it, say so. Never invent a name, date, price or number.
- When you use a fact from one of my files, say which file it came from.
- Write dates as YYYY-MM-DD.
- If my request is unclear, ask me one question instead of guessing.
- Never write a password or bank detail into anything.
- Match the tone described above, not standard business writing.
```

Then, in the next file of this kit, you paste this MASTER file into ChatGPT or Claude once and it stays there permanently. That is the moment the whole thing clicks.

Keep it under two pages. A MASTER file nobody reads because it is nine pages long is worth nothing.

## Step four: your first client page

Pick your most important client. Create `03_Clients/Acme_Ltd.md`, using their real name in the filename, and fill this in.

Most business questions turn out to be client questions, which is why this page does more work than any other.

```markdown
---
title: Client - Acme Ltd
description: Everything we know about Acme Ltd, in one page.
---

# Client: Acme Ltd

## Basics

- Main contact: name, role
- Other contacts:
- What they buy from us:
- Price and terms:
- Client since:
- Renewal or review date:

## How they like to work

Their communication style, preferred channel, how fast they reply,
anything that keeps the relationship smooth.

## Where things stand

- Status: healthy | needs attention | at risk
- Last contact: 2026-07-14, about what
- Open items:
  - [ ]

## History

Newest first. One line per thing that mattered.

- 2026-07-14 Quarterly review

## Risks and opportunities

-
```

Aim for honest, not complete. Blanks are fine. A half-filled page you actually use beats a perfect one you built once and never opened.

## The rest of the templates

You do not need these in the first twenty minutes. Come back when the moment arrives.

### A project

Make a folder in `02_Active_Projects` named after the project, then put these two files inside it.

`PROJECT.md`:

```markdown
---
title: PROJECT
description: What this project is and where it stands.
---

# Project: <name>

## Goal

One or two sentences. What done looks like.

## Why it matters

One paragraph maximum.

## Status

- State: not started | in progress | blocked | done
- Last updated: 2026-07-14
- Next milestone:
- Target date:

## People

- Owner:
- Also involved:

## Background

Where this came from, what constraints exist (budget, deadline,
things we must not break), and what has already been tried.
```

`TASKS.md`:

```markdown
---
title: TASKS
description: Live task list for this project.
---

# Tasks: <project name>

## Now

- [ ] The single most important next action
- [ ]

## Next

- [ ]

## Waiting on

- [ ] What we are waiting for, who from, since when

## Done

- [x] 2026-07-10 Example finished task
```

Tick things off with `[x]` and move them down to Done rather than deleting them. The history is worth more than the tidiness.

### A meeting note

Goes in `06_Meetings`, named `YYYY-MM-DD_Subject.md`.

```markdown
---
title: Meeting - Acme quarterly review
description: Notes from 2026-07-14.
---

# Meeting: <subject>

- Date: 2026-07-14
- Who was there:
- Client or project:

## What was discussed

Short bullets. What they said matters more than what you said.

-

## Decisions made

-

## Actions

- [ ] Action, who owns it, when by

## For next time

Anything to remember before you speak to them again.
```

### A decision

Inside each project folder, make a `DECISIONS` folder. One file per decision, named by date: `2026-07-14_switched_supplier.md`.

Decisions are the most valuable thing you will ever put in here. Six months from now, "why on earth did we do it that way" is the question you will ask most, and it is the one nobody can answer.

```markdown
---
title: Decision - switched supplier
description: Why we switched and what else we looked at.
---

# Decision: <short title>

- Date: 2026-07-14
- Decided by:
- Status: decided | revisit on <date>

## What we decided

One or two sentences.

## Why

The real reasons, in plain language.

## What we said no to

- Option B, because:
- Option C, because:

## What this commits us to

What we would have to undo if we changed our mind.
```

### Recurring costs

`04_Finance_Admin/Recurring_Costs.md`. Fill it once, thank yourself every quarter.

```markdown
---
title: Recurring Costs
description: Every subscription and recurring supplier cost.
---

# Recurring Costs

| Item | Supplier | Cost | Billing | Renewal date | Notice needed |
|---|---|---|---|---|---|
| Accounting software | | £/mo | Monthly | | 30 days |
| Insurance | | £/yr | Annual | | |
```

## Three naming habits

These three make the difference between a folder you can search and a folder you avoid opening.

1. **Dates first, year first.** `2026-07-14_Acme_Review.md` sorts itself. `Acme review July.md` does not.
2. **Underscores instead of spaces.** `Acme_Ltd.md`, not `Acme Ltd.md`. Spaces cause trouble in places you cannot predict, and underscores never do.
3. **One subject per page.** A page called `Acme_Ltd.md` holding everything about Acme is good. A page called `Misc.md` is where information goes to die.

## Do this now

Open Obsidian, create `00_System/MASTER.md`, and fill in the first section only: who you are, what you sell, who you sell it to, what you charge. Four lines. Everything else can wait until this evening, but those four lines are what makes the next file work.
