AI Company Brain Starter Kit

Start here:
1. Open the PDF and read 00_START_HERE (5 minutes).
2. Open the Company_Brain_Vault folder in Obsidian.
3. Fill in 00_System/MASTER.md.

Guides/ has the same guides as plain text files.

heoka.co.uk
