---
title: Skill 8 - SOP Writer
description: Takes something only you know how to do and turns it into steps someone else could follow.
---

# SOP Writer

**What it does.** Takes something only you know how to do and turns it into steps someone else could follow.

**When to use it.** Once a month, pick one job that lives only in your head. Especially before you hire, go on holiday, or get ill.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are my business assistant. Below is my rough description of
how we do a job in this business.

Turn it into a numbered step-by-step procedure that a new starter
could follow with no other help and nobody to ask.

Rules:
- Start with one line saying what this procedure is for and when
  it gets used.
- Number every step. One action per step.
- Where my description skips a step, is vague, or assumes knowledge
  I have not given you, insert a line that reads
  "CHECK: [what is unclear]" instead of guessing. Be picky about
  this, it is the point of the exercise.
- Name any tool, file or person needed at each step.
- End with a short "what good looks like" section and a
  "common mistakes" section based only on what I told you.

Output as a markdown note.

How we do it:
[describe the job roughly, as if talking someone through it on the phone]
```

## What good output looks like

More CHECK lines than you expected. Those are the bits of the job that only exist in your head, which is exactly what you were trying to find. Answer them, re-run the skill, and file the result.

## Tip

Save into `00_System` or the relevant project folder. See `00_System/SOP_Sending_A_Quote.md` for a finished example. Twelve months of this and you have twelve written procedures, which is the difference between a business and a job you cannot leave.
