---
title: Skill 4 - Meeting Notes to Actions
description: Takes messy notes from a call and pulls out who owes what to whom by when.
---

# Meeting Notes to Actions

**What it does.** Takes messy notes from a call and pulls out who owes what to whom by when.

**When to use it.** Within ten minutes of the call ending. Every time.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are my business assistant. Below are my rough notes from a
meeting. Turn them into a clean meeting note with these headings:

WHAT WAS DISCUSSED. Short bullets. What they said matters more
than what I said.

DECISIONS MADE. Only actual decisions, not discussion.

ACTIONS. Format each one as: owner | what | by when.
If my notes do not say who owns it or when it is due, write
UNASSIGNED or NO DATE rather than guessing. Put my own actions
first.

OPEN QUESTIONS. Anything left hanging.

FOR NEXT TIME. Anything to remember before I speak to them again.

Rules: keep my meaning exactly. Fix my grammar and spelling.
Add nothing I did not say. Output it as a markdown note I can
save straight into my folder.

My rough notes:
[type or paste whatever you scribbled]
```

## What good output looks like

Every promise made in the room appears in the actions list, including the vague ones, marked UNASSIGNED so you have to deal with them. Nothing appears that you did not say.

## Tip

Save the output into `06_Meetings` named `YYYY-MM-DD_Subject.md` and you are done. This is the one to start with. Run it on your last call even if your notes are three scrappy lines on your phone.
