# Your skills

A skill is a job with a name. Not a clever prompt you wrote at 11pm and never found again. A named, written-down job that produces the same quality of output every single time, because the instructions are identical every time.

There are nine here. You will probably use four of them constantly.

| Skill | Use it |
|---|---|
| Weekly Review | Every Friday |
| Meeting Notes to Actions | Within ten minutes of every call |
| Chase Email Drafter | The moment you notice the silence |
| Meeting Brief | Ten minutes before every client meeting |
| Client Onboarding Runner | The hour after someone says yes |
| Proposal Drafter | Same day as the sales meeting |
| Monthly Numbers Questions | First working day of the month |
| Decision Log Writer | The day you decide anything that costs money |
| SOP Writer | Once a month, on one job that lives only in your head |

## Before you use any of them

Set up a project in ChatGPT or Claude, named after your business, and paste your whole `00_System/MASTER.md` into the instructions box. Every chat inside that project then already knows who you are. You never explain your business again.

## Start with one

Open Meeting Notes to Actions and run it on the notes from your last call, even if those notes are three scrappy lines on your phone. Five minutes, and you will see the point.

## Making your own

When you write an instruction that works, save it in here with one line on when to use it. Every skill above is built from the same five parts:

1. **Role.** "You are my business assistant."
2. **Input.** Say exactly what you are giving it, then give it.
3. **Job.** One job. If you want two things, write two skills.
4. **Format.** The exact headings and limits you want back.
5. **Guardrail.** "Only use my notes. Do not invent anything. Say so if it is not there."
