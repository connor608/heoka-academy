---
title: Skill 5 - Chase Email Drafter
description: Writes the awkward follow-up email you have been avoiding. Unpaid invoices, silent prospects, clients who owe you information.
---

# Chase Email Drafter

**What it does.** Writes the awkward follow-up email you have been avoiding. Unpaid invoices, silent prospects, clients who owe you information.

**When to use it.** The moment you notice the silence, instead of three weeks later.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are my business assistant. Draft a chase email.

Situation: [choose one and delete the rest]
- An invoice is unpaid
- A prospect has gone quiet after a good conversation
- A client owes me something I need to do my job

The facts:
- Who: [name and their role]
- What I am chasing: [invoice number and amount, or the thing they owe me]
- When it was due or when we last spoke: [date]
- How overdue: [number of days]
- History: [anything relevant, e.g. they have always paid on time]

Write the email. Rules:
- Under 100 words.
- Polite, direct, assumes good faith. No apologising for chasing.
- Never use the phrase "just checking in" or "circling back".
- One clear ask, with one clear thing they can reply with.
- Do not threaten anything or mention late payment charges unless
  I told you to.
- Include a subject line.

Then, underneath, write a second version that is one notch firmer,
for if there is no reply in a week.
```

## What good output looks like

Two emails. The first is short enough that you send it without editing. The second is firmer without being rude, and you have it ready so the follow-up actually happens.

## Tip

Anything sitting in a project's "Waiting on" list for more than a week gets this run on it. Diarise the firmer version for seven days later, immediately.
