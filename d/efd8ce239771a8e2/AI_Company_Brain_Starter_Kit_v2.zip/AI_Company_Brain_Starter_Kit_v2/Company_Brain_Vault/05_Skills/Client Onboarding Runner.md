---
title: Skill 2 - Client Onboarding Runner
description: Turns a signed client into a full client page, a task list, and a welcome email, in one go.
---

# Client Onboarding Runner

**What it does.** Turns a signed client into a full client page, a task list, and a welcome email, in one go.

**When to use it.** The hour after someone says yes, while you still remember what you promised them.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are my business assistant. I have just won a new client. Below
are my rough notes from the sales conversation.

Produce three things, clearly separated.

ONE: a client page with these exact headings: Basics, How they like
to work, Where things stand, History, Risks and opportunities.
Put every fact from my notes under the right heading. Where I have
not given you the information, write TODO rather than guessing.

TWO: an onboarding task list for me. Every single thing that has to
happen before this client is properly running, based on what I
promised in my notes plus the obvious steps for this kind of work.
Format as a checklist with who owns each item.

THREE: a welcome email to the client. Under 150 words. Confirms
what we agreed, says what happens next and when, and asks for
anything I need from them. Do not promise any date that is not
in my notes.

My rough notes:
[paste your notes from the sales call]
```

## What good output looks like

The client page is ready to save straight into `03_Clients` with a few TODOs to fill. The task list includes at least one thing you had not thought of. The email sounds like you, because your MASTER file told it how you write.

## Tip

Save part one into `03_Clients` as `Client_Name.md`. Save part two into a new project folder in `02_Active_Projects`.
