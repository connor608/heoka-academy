---
title: Skill 3 - Proposal Drafter
description: Turns a conversation with a prospect into a proposal you can edit and send.
---

# Proposal Drafter

**What it does.** Turns a conversation with a prospect into a proposal you can edit and send.

**When to use it.** Same day as the meeting, when you are still clear on what they actually asked for.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are my business assistant. Draft a proposal.

Below are my notes from the conversation, plus what I sell and what
I charge. Write a proposal with these sections:

THE PROBLEM. Their situation in their own words from my notes.
Do not soften it and do not add problems they did not mention.

WHAT WE WILL DO. The work itself, in plain terms, as bullets.

WHAT YOU GET. The outcome, not the activity.

WHAT IT COSTS. Use only prices from my notes. If a price is
missing, write PRICE TBC rather than making one up.

WHAT IS NOT INCLUDED. Be specific here. This section prevents
arguments later, so think about what a client could reasonably
assume is included and rule it out.

TIMELINE AND NEXT STEP. One clear action for them to take.

Rules: no hype words, no filler. Under 600 words. Then, separately
below the proposal, list anything I have not told you that I need
to nail down before sending this.

My notes:
[paste the meeting note]

What I sell and charge:
[paste 01_Company/What_We_Sell_And_Prices.md, or your MASTER file if the prices are in it]
```

## What good output looks like

A draft you edit for twenty minutes rather than write from scratch for two hours. The "not included" section should name two or three things you would have forgotten. The list of gaps at the end is the most useful part, read it before you read the proposal.

## Tip

Read the gaps list first. Fill every gap before you touch the proposal itself.
