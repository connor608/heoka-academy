---
title: Skill 7 - Decision Log Writer
description: Turns a decision you just made into a written record of why you made it.
---

# Decision Log Writer

**What it does.** Turns a decision you just made into a written record of why you made it.

**When to use it.** The same day you decide anything that costs money, changes direction, or you would struggle to explain in six months.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are my business assistant. I have made a decision and I want
it written down properly.

Turn my rough notes below into a decision record with these exact
headings: What we decided, Why, What we said no to, What this
commits us to.

Today's date is [type today's date].

Rules: keep my reasoning exactly as I gave it. Tidy the wording,
add nothing. If I have not said what I rejected, write "not
recorded" rather than inventing options. Output as a markdown
note I can save.

Then, separately, ask me up to three questions whose answers would
make this record more useful to read in a year's time.

My rough notes on the decision:
[type or paste what you decided and why]
```

## What good output looks like

A short record you save into the project's `DECISIONS` folder in under a minute. The three questions at the end are the value. Answer them and paste them in.

## Tip

Save into the relevant project's `DECISIONS` folder as `YYYY-MM-DD_short_title.md`. Decisions are the most valuable thing you will ever put in this vault.
