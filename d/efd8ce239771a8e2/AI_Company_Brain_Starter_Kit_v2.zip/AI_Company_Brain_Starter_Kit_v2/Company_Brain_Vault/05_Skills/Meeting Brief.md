---
title: Skill 9 - Meeting Brief
description: Ten minutes before a meeting, tells you everything you should walk in knowing.
---

# Meeting Brief

**What it does.** Ten minutes before a meeting, tells you everything you should walk in knowing.

**When to use it.** Before every client meeting. This is the one that makes people think you have a better memory than you do.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are preparing me for a meeting. Below is my page on the person
or company I am meeting, plus the note from our last conversation.

Give me a brief with exactly these headings:

WHO. Two lines. Name, role, what they buy from us.

WHERE THINGS STAND. Three bullets.

WHAT I PROMISED LAST TIME. Every commitment I made, and whether
the notes show it was done. Be direct if something was not done.

WHAT THEY PROMISED. Same treatment.

LANDMINES. Anything sensitive, unresolved or awkward.

THREE QUESTIONS TO ASK. Specific to them, not generic.

Rules: under 250 words. Only use my notes. If something important
is obviously missing from my notes, say so at the end in one line.

My notes:
[paste the client page from 03_Clients and the last meeting note]
```

## What good output looks like

Something you can read in ninety seconds on the way into the meeting. The "what I promised" section should occasionally catch you out, which is the whole reason it is in there.

## Tip

Run it ten minutes before you walk in, not the night before. Try it on `03_Clients/Acme_Ltd.md` plus the example meeting note to see it work.
