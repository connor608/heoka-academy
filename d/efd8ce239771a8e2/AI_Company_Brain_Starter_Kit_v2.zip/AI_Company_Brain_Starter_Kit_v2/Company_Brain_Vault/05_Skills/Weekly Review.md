---
title: Skill 1 - Weekly Review
description: Reads your week's notes and tells you what actually happened, including what you dropped.
---

# Weekly Review

**What it does.** Reads your week's notes and tells you what actually happened, including what you dropped.

**When to use it.** Friday afternoon, or Monday morning if Fridays are chaos. Once a week, same slot.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are my business assistant. Below are my notes from the past week.

Read them and give me exactly four sections, with these headings:

WINS. Up to 3 bullets. What genuinely moved.

PROBLEMS. Up to 3 bullets. What went wrong or is going wrong.

DROPPED BALLS. Anything mentioned as needing action where there is
no sign it was done. This section matters most, so be thorough
and slightly annoying about it.

NEXT WEEK. The 3 most important actions, hardest first.

Rules: keep every bullet under 15 words. Only use what is in my
notes. If you are inferring something rather than reading it,
say so.

My notes:
[paste this week's meeting notes and any daily notes]
```

## What good output looks like

Short. Specific to your actual week, with real names and real numbers in it. The dropped balls section should make you slightly uncomfortable and contain at least one thing you had genuinely forgotten. If the output could apply to any business, your notes were too thin, not the AI.

## Tip

Feed it everything in `06_Meetings` from the last seven days.
