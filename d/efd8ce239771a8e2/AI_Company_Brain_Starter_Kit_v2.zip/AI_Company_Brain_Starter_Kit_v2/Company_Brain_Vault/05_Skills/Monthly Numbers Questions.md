---
title: Skill 6 - Monthly Numbers Questions
description: Looks at your costs and admin facts and asks the questions you should be asking yourself.
---

# Monthly Numbers Questions

**What it does.** Looks at your costs and admin facts and asks the questions you should be asking yourself.

**When to use it.** Once a month, when the card statements land. First working day of the month works well.

## Paste this

*Paste this into your ChatGPT or Claude project chat, then paste whatever it asks for underneath, then send. Where it says `[paste ...]`, copy the text out of the relevant page in this vault (click into the note, Cmd+A or Ctrl+A, then Cmd+C or Ctrl+C) and paste it in place of the brackets. You can attach the file instead if you prefer.*

```text
You are a blunt finance-minded adviser. Below are my recurring
costs and admin notes.

Give me four things.

ONE: a table with columns Item, Cost per month (convert any annual
figures to monthly), and Keep or Question. Mark as Question
anything that looks duplicated, unused based on my notes, or
expensive for what it is.

TWO: the total monthly cost, and the total of everything you
marked Question. Show your working for the annual conversions.

THREE: every date, deadline and renewal you can find in my notes,
sorted earliest first, in the format DATE | what it is. Today is
[type today's date]. Put SOON at the start of anything in the
next 30 days.

FOUR: the five questions I should be able to answer about this
business and probably cannot from these notes alone. Be specific
to what you can see, not generic.

Do not invent any figure or date. If something is missing, say
it is missing.

My notes:
[paste 04_Finance_Admin/Recurring_Costs.md and any other admin notes]
```

## What good output looks like

A table you check the arithmetic on yourself, at least two subscriptions you had forgotten you pay for, and a renewal date you were about to be ambushed by. Section four is the one worth reading twice.

## Tip

Check its arithmetic yourself. Then cancel one thing you are paying for and not using. There is almost always one. Diarise anything it flagged for the next 30 days.
