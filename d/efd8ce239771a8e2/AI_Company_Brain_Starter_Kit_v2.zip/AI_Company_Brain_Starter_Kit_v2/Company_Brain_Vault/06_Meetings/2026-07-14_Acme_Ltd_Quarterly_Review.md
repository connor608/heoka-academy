---
title: Meeting - Acme quarterly review
description: Notes from 2026-07-14.
---

# Meeting: Acme Ltd quarterly review

*This is an example note so you can see what a good one looks like. Delete it once you have written your own.*

- Date: 2026-07-14
- Who was there: Sarah Whitfield (Acme), Dan Corley (us). Tom joined for the last five minutes.
- Client or project: Acme Ltd, care plan

## What was discussed

Short bullets. What they said matters more than what you said.

- Sarah says the site "feels slow on her phone", especially the gallery page. She has not measured it, it is a feeling.
- The contact form failure in early July is still sore. She found out from a customer, not from us.
- Enquiries are up on last year but she cannot tell us by how much, because nobody looks at the numbers.
- Tom asked, again, what the £95 a month actually buys. Third time this year.
- Their hire arm is being spun out as a separate brand in the autumn and "will probably need its own site".

## Decisions made

- We will send a one page monthly summary of what the care plan did that month, starting August.
- We will look at page speed on the gallery page before the end of July, at no charge.

## Actions

- [ ] Dan | send updated care plan terms with the monthly summary included | by 2026-07-18
- [ ] Dan | check gallery page speed and report back | by 2026-07-31
- [ ] Kelly (Acme) | send photos of the Bolton job | no date agreed, chase in a week
- [ ] Dan | quote the hire arm site | after Sarah confirms the brand name, expected September

## For next time

Tom is the risk, not Sarah. He sees a direct debit and no visible work. Walk into the next call with the monthly summaries printed. Do not open with the hire arm quote, open with what the care plan caught.
