# Start here

Open this folder in Obsidian. Then open `00_System/MASTER.md`.

**How to open it.** Download Obsidian from obsidian.md, install it, click **Open folder as vault**, and choose this folder. That is the only thing you install.

**What is in here.**

- `00_System` - the MASTER file that tells the AI who your business is. Blank copies of every page live in `00_System/Templates`.
- `01_Company` - what you sell and what it costs.
- `02_Active_Projects` - one folder per live project.
- `03_Clients` - one page per client.
- `04_Finance_Admin` - renewals, suppliers, recurring costs.
- `05_Skills` - nine ready-made jobs you paste into ChatGPT or Claude.
- `06_Meetings` - every meeting note, named by date.
- `99_Archive` - finished work. Move things here instead of deleting them.

Every folder already has one filled-in example so you can see what good looks like. Overwrite the examples with your own work, or delete them once you have your own.

One rule: no passwords, no bank details, no card numbers, ever.
