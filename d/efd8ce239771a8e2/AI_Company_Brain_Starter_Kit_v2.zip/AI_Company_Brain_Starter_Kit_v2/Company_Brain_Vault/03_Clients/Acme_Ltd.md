---
title: Client - Acme Ltd
description: Everything we know about Acme Ltd, in one page.
---

# Client: Acme Ltd

*This is an example page so you can see what a good one looks like. Delete it once you have written your own. The blank copy is in `00_System/Templates`.*

## Basics

- Main contact: Sarah Whitfield, Operations Director. Makes the decisions, but Tom signs anything over £2,000.
- Other contacts: Tom Whitfield, owner, rarely replies. Kelly on reception, useful for scheduling.
- What they buy from us: Website build (done 2024), care plan since go live.
- Price and terms: £95 a month care plan, paid by direct debit on the 1st. Extra work at £340 a half day.
- Client since: 2024-03-11
- Renewal or review date: 2026-09-01

## How they like to work

Email for anything with a price in it, WhatsApp for everything else. Sarah replies within the hour. Tom replies in about a week or not at all, so do not wait on him unless you have to. They hate long documents. Send three bullets and a price.

## Where things stand

- Status: needs attention
- Last contact: 2026-07-14, quarterly review call
- Open items:
  - [ ] Send the updated care plan terms, promised 2026-07-14
  - [ ] Get new photos of the Bolton job from Kelly
  - [x] Fixed the contact form, 2026-07-02

## History

Newest first. One line per thing that mattered.

- 2026-07-14 Quarterly review. Sarah raised page speed and hinted at a second site for their hire arm.
- 2026-07-02 Contact form was silently failing for about ten days. Nobody told us. We found it.
- 2026-04-08 Paid two weeks late for the first time ever. Sarah apologised, said it was a bank change.
- 2024-03-11 Signed. Site live 2024-05-02.

## Risks and opportunities

- Risk: the contact form failure cost them enquiries and they have not forgotten it. Handle the next fault fast and loudly.
- Risk: Tom has mentioned "what are we paying for" twice this year. The care plan needs to be visibly earning its keep before September.
- Opportunity: the hire arm needs its own site. Sarah raised it, we have not quoted. Worth about £4,000.
