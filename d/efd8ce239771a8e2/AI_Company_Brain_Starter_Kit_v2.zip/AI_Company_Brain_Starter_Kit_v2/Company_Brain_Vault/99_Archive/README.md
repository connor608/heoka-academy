# Archive

Finished projects, former clients, dead documents. Move things here instead of deleting them.

Do this in the last ten minutes of your monthly hour. A folder where everything visible is live is a folder you can trust at a glance. A folder full of dead projects is one you start avoiding.

Delete nothing.
