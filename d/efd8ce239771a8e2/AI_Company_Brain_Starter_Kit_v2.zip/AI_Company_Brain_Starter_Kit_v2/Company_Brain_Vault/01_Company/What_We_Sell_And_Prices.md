---
title: What We Sell And Prices
description: The list of what we do and what it costs. Example filled in.
---

# What we sell and what it costs

*This is an example. Replace it with your own.*

| What it is | What the client gets | Price | Notes |
|---|---|---|---|
| Website build | A five to eight page site, live, with their photos | From £3,500 | 50% deposit up front. Six to eight weeks. |
| Care plan | Hosting, updates, backups, one hour of changes a month | £95 a month | Rolling, 30 days notice either side. |
| Half day of changes | Four hours of work on an existing site | £340 | For clients not on a care plan. |
| Rescue job | Fixing a site somebody else built | £900 audit first | We do not quote the fix until the audit is done. |

## What is never included unless we say so in writing

- Photography
- Writing the words on the page
- Anything to do with their email accounts
- Ongoing changes after go live, unless they are on a care plan

## Who we sell to

Owner-run trade businesses in Greater Manchester, five to forty staff. Builders, electricians, landscapers.

## Who we do not sell to

Anyone who wants it in under three weeks. Anyone who will not give us photos of their own work. Startups without a trading history.
