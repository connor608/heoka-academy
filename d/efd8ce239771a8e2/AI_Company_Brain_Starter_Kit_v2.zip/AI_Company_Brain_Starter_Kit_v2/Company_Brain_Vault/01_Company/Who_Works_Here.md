---
title: Who Works Here
description: The people, what they own, and what only they can do.
---

# Who works here

*This is an example. Replace it with your own.*

| Name | Role | What they own | What only they can do |
|---|---|---|---|
| Dan Corley | Owner | Sales, pricing, all client contact | Quote a job, sign anything |
| Priya Shah | Designer, 2 days a week | Layout, images, build quality | Sign off a design before it goes live |

## Cover

If Dan is off, nothing gets quoted. Priya can keep builds moving and answer factual questions from the client pages in `03_Clients`, but she does not agree prices or dates.
