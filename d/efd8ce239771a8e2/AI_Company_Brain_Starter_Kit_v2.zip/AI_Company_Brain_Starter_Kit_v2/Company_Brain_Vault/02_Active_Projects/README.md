# Active projects

One folder per live project. A project is anything with an end: a rebuild, a launch, a big proposal.

Inside each folder, put:

- `PROJECT.md` - what it is and where it stands
- `TASKS.md` - the live task list
- `DECISIONS/` - one file per decision, named by date

`Website_Rebuild` is a filled-in example. Copy the shape of it, then delete it.

Blank copies of all three are in `00_System/Templates`.
