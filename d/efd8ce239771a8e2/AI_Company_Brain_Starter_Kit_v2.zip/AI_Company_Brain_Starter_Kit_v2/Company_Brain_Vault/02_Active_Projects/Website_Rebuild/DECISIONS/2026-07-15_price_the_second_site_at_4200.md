---
title: Decision - price the second site at £4,200
description: Why we picked that number and what else we considered.
---

# Decision: price the hire arm site at £4,200

*Example decision record. Delete it once you have a real one.*

- Date: 2026-07-15
- Decided by: Dan Corley
- Status: decided

## What we decided

Quote Acme's hire arm site at £4,200 plus a second care plan at £95 a month, with no discount for being an existing client.

## Why

We lost a near identical job in 2025 at £3,800 and the winner did it badly, so price was not really the reason. Acme are not price shopping, they came to us. Discounting a second site teaches Tom that the first price was soft, and he is already the one questioning value. The extra £400 over the 2025 quote covers the fact that this one has a hard launch date and no slippage room.

## What we said no to

- £3,500 with the care plan bundled free for six months, because it hides the price of the care plan and makes it harder to defend later.
- Day rate instead of a fixed price, because the launch date is fixed and the risk of overrun should sit with us, not them.

## What this commits us to

Delivering before the October trade show with no room to move. If the brand name is not confirmed by the middle of August, we have to either say no or renegotiate the date, and saying that early will be cheaper than saying it late.
