---
title: PROJECT
description: What this project is and where it stands.
---

# Project: Acme hire arm website

*Example project. Delete it once you have a real one.*

## Goal

A five page site for Acme's hire arm, live before their autumn launch, with enquiries going to a real inbox somebody watches.

## Why it matters

It is worth about £4,000 and a second care plan. It also settles the Tom problem: if we build the second site well, the question of what the £95 a month buys stops being asked.

## Status

- State: blocked
- Last updated: 2026-07-14
- Next milestone: brand name confirmed so we can register the domain
- Target date: 2026-09-26

## People

- Owner: Dan Corley
- Also involved: Priya Shah (design), Sarah Whitfield (Acme, decisions), Tom Whitfield (signs anything over £2,000)

## Background

Came out of the quarterly review on 2026-07-14, unprompted by us. Constraints: the launch date is fixed by their trade show in October, so the site cannot slip. We must not touch the existing Acme site while doing this, because it is on a care plan and any downtime there is our fault. We quoted a similar job for a hire firm in 2025 at £3,800 and lost it on price, so pitch carefully.
