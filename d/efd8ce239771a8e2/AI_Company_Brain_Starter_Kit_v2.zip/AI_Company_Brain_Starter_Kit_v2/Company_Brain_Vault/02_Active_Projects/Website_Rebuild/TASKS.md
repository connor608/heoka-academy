---
title: TASKS
description: Live task list for this project.
---

# Tasks: Acme hire arm website

## Now

- [ ] Get the brand name confirmed by Sarah so the domain can be registered
- [ ] Write the quote and send it, using Skill 3 (Proposal Drafter)

## Next

- [ ] Register the domain once the name is confirmed
- [ ] Agree the five pages with Sarah before any design starts
- [ ] Book Priya for two weeks in August

## Waiting on

- [ ] Brand name, from Sarah, since 2026-07-14
- [ ] Photos of the Bolton job, from Kelly, since 2026-07-14

## Done

- [x] 2026-07-14 Sarah raised the second site at the quarterly review
- [x] 2026-07-15 Checked our 2025 hire firm quote for a price reference
