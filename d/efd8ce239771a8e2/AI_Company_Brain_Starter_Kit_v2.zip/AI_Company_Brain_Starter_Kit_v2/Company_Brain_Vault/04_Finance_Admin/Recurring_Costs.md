---
title: Recurring Costs
description: Every subscription and recurring supplier cost.
---

# Recurring Costs

*This is an example. Replace the rows with your own. Fill it once, thank yourself every quarter.*

| Item | Supplier | Cost | Billing | Renewal date | Notice needed |
|---|---|---|---|---|---|
| Accounting software | Xero | £33/mo | Monthly | 2026-11-04 | 30 days |
| Public liability insurance | Hiscox | £420/yr | Annual | 2026-10-19 | None, but shop around a month early |
| Website hosting | Krystal | £180/yr | Annual | 2027-01-22 | None |
| Design software | Adobe | £52/mo | Annual, paid monthly | 2026-08-30 | Cancelling early costs 50% of the rest |
| Email and files | Google Workspace | £28/mo | Monthly | Rolling | None |
| Stock photos | Envato | £16/mo | Monthly | Rolling | None. Nobody has used it since February. |
| Scheduling tool | Calendly | £12/mo | Monthly | Rolling | None. Duplicates what Google Calendar does. |

## Notes

- The Adobe renewal on 2026-08-30 is the one to watch. It locks in for another year the day it renews.
- Envato and Calendly are the two obvious cancellations. That is £28 a month, £336 a year.
- Insurance renews in October. Last year we did not shop around and it went up 19%.

## Suppliers and terms

| Supplier | What they do | Contact | Payment terms |
|---|---|---|---|
| Krystal | Hosting | support@ ticket only | Annual, in advance |
| Priya Shah | Design, 2 days a week | WhatsApp | Invoiced monthly, paid within 7 days |

---

*Run Skill 6 (Monthly Numbers Questions) on this page on the first working day of every month. Check its arithmetic yourself.*
