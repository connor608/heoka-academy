---
title: SOP - Sending a quote
description: How we do this job, step by step.
---

# How we send a quote

**What this is for and when it gets used.** Every time a prospect asks for a price, within 24 hours of the call. Used by Dan only, because only Dan quotes.

## Steps

1. Open the meeting note for that call in `06_Meetings` and reread it before you write anything.
2. Open `01_Company/What_We_Sell_And_Prices.md` and find the closest matching job.
3. Run Skill 3 (Proposal Drafter) in `05_Skills`, pasting in the meeting note and the prices page.
4. Read the list of gaps the skill gives you at the end. Fill every gap before you touch the proposal itself.
5. Edit the draft. Cut anything that reads like marketing.
6. Check the "What is not included" section names at least three things. If it does not, add them.
7. Save the final version as a PDF named `YYYY-MM-DD_ClientName_Quote.pdf`.
8. Email it with the price in the body of the email, not only in the attachment.
9. Add a line to the client's page in `03_Clients` under History, with the date and the amount.
10. Put a reminder in the calendar for five working days later to chase.

## What good looks like

- Out within 24 hours of the call.
- Under 600 words.
- The client can see the price without opening the attachment.
- The chase reminder exists before you close the laptop.

## Common mistakes

- Quoting a price that was never discussed on the call.
- Forgetting to rule out the things clients assume are included, especially photography and copywriting.
- Sending it and not diarising the chase, which is how quotes die.
