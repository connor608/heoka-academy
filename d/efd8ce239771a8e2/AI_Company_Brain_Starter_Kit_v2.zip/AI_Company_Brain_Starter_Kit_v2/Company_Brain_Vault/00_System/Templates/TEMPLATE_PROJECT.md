---
title: PROJECT
description: What this project is and where it stands.
---

# Project: <name>

## Goal

<< One or two sentences. What done looks like. >>

## Why it matters

<< One paragraph maximum. >>

## Status

- State: not started | in progress | blocked | done
- Last updated: << YYYY-MM-DD >>
- Next milestone: <<  >>
- Target date: << YYYY-MM-DD >>

## People

- Owner: <<  >>
- Also involved: <<  >>

## Background

<< Where this came from, what constraints exist (budget, deadline, things we must not break), and what has already been tried. >>
