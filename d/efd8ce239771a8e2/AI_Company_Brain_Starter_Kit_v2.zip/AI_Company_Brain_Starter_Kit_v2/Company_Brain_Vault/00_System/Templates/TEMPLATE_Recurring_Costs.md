---
title: Recurring Costs
description: Every subscription and recurring supplier cost.
---

# Recurring Costs

| Item | Supplier | Cost | Billing | Renewal date | Notice needed |
|---|---|---|---|---|---|
| << Accounting software >> | <<  >> | £ /mo | Monthly | << YYYY-MM-DD >> | 30 days |
| << Insurance >> | <<  >> | £ /yr | Annual | << YYYY-MM-DD >> | <<  >> |

---

*Fill it once, thank yourself every quarter. Run Skill 6 (Monthly Numbers Questions) on it on the first working day of every month. See `04_Finance_Admin/Recurring_Costs.md` for a filled-in example.*
