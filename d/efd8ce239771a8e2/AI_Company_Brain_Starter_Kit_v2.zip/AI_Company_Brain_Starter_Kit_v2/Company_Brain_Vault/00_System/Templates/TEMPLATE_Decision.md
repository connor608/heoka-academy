---
title: Decision - <short title>
description: Why we decided this and what else we looked at.
---

# Decision: <short title>

- Date: << YYYY-MM-DD >>
- Decided by: <<  >>
- Status: decided | revisit on << YYYY-MM-DD >>

## What we decided

<< One or two sentences. >>

## Why

<< The real reasons, in plain language. >>

## What we said no to

- << Option B, because: >>
- << Option C, because: >>

## What this commits us to

<< What we would have to undo if we changed our mind. >>

---

*Save this in the project's `DECISIONS` folder, named `YYYY-MM-DD_short_title.md`. Six months from now, "why on earth did we do it that way" is the question you will ask most, and this is the only thing that answers it.*
