---
title: Meeting - <subject>
description: Notes from <YYYY-MM-DD>.
---

# Meeting: <subject>

- Date: << YYYY-MM-DD >>
- Who was there: <<  >>
- Client or project: <<  >>

## What was discussed

Short bullets. What they said matters more than what you said.

- <<  >>

## Decisions made

- <<  >>

## Actions

- [ ] << action, who owns it, when by >>

## For next time

<< Anything to remember before you speak to them again. >>

---

*Save this in `06_Meetings` named `YYYY-MM-DD_Subject.md`. Write it the same day, always. A meeting note written on Friday about Tuesday's meeting is fiction.*
