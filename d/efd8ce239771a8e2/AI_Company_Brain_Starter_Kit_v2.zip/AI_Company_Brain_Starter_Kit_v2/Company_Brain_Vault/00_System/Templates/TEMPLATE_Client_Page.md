---
title: Client - <name>
description: Everything we know about <name>, in one page.
---

# Client: <name>

## Basics

- Main contact: << name, role >>
- Other contacts: <<  >>
- What they buy from us: <<  >>
- Price and terms: <<  >>
- Client since: << YYYY-MM-DD >>
- Renewal or review date: << YYYY-MM-DD >>

## How they like to work

<< Their communication style, preferred channel, how fast they reply, anything that keeps the relationship smooth. >>

## Where things stand

- Status: healthy | needs attention | at risk
- Last contact: << YYYY-MM-DD, about what >>
- Open items:
  - [ ] <<  >>

## History

Newest first. One line per thing that mattered.

- << YYYY-MM-DD what happened >>

## Risks and opportunities

- <<  >>

---

*Aim for honest, not complete. Blanks are fine. A half-filled page you actually use beats a perfect one you built once and never opened. See `03_Clients/Acme_Ltd.md` for a filled-in example.*
