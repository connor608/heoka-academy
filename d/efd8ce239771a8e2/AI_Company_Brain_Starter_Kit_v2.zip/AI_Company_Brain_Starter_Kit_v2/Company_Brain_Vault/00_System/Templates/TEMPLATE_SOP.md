---
title: SOP - <name of the job>
description: How we do this job, step by step.
---

# How we <do the job>

**What this is for and when it gets used.** << one line >>

## Steps

1. << one action per step. Name the tool, file or person needed. >>
2. <<  >>
3. <<  >>

## What good looks like

- <<  >>

## Common mistakes

- <<  >>

---

*Run Skill 8 (SOP Writer) in `05_Skills` and it will fill this in from you talking it through. Anywhere it writes `CHECK:`, that is a bit of the job that only exists in your head. Answer those and run it again.*
