---
title: TASKS
description: Live task list for this project.
---

# Tasks: <project name>

## Now

- [ ] << the single most important next action >>
- [ ] <<  >>

## Next

- [ ] <<  >>

## Waiting on

- [ ] << what we are waiting for, who from, since when >>

## Done

- [x] << YYYY-MM-DD finished task >>

---

*Tick things off with `[x]` and move them down to Done rather than deleting them. The history is worth more than the tidiness.*
