---
title: How This Vault Works
description: The three naming habits and where things go.
---

# How this vault works

## Where things go

| What happened | Where it goes |
|---|---|
| Something about a client | `03_Clients`, update their page |
| Something about a project | `02_Active_Projects`, update TASKS.md |
| A meeting or a call | `06_Meetings`, a new dated note |
| Money or admin | `04_Finance_Admin` |
| A decision | The project's `DECISIONS` folder, one file per decision |
| Finished or dead | `99_Archive` |

## Three naming habits

1. **Dates first, year first.** `2026-07-14_Acme_Review.md` sorts itself. `Acme review July.md` does not.
2. **Underscores instead of spaces.** `Acme_Ltd.md`, not `Acme Ltd.md`. Spaces cause trouble in places you cannot predict.
3. **One subject per page.** A page called `Acme_Ltd.md` is good. A page called `Misc.md` is where information goes to die.

The numbers on the folders are not decoration. They force the same sort order everywhere, and they tell you how often you touch each folder. Low numbers are rules and facts that barely change. Middle numbers are live work. 99 is the attic.

## The one hard rule

No passwords, no bank details, no card numbers, ever. Those belong in a password manager. This folder holds facts, not secrets.

## Blank copies

Every template in this vault has a blank copy in `00_System/Templates`. Copy one, rename it, fill it in.
